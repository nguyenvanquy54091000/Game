﻿using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public int score = 0;
    //public Text scoreText;
    public TextMeshProUGUI scoreText ; 
    
    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
    void Start()
    {
        scoreText = GameObject.Find("scoreText").GetComponent<TextMeshProUGUI>();
        if (scoreText == null)
        {
            Debug.LogError("Không tìm thấy TextMeshProUGUI để hiển thị điểm!");
        }
    }

    void Update()
    {
        if (scoreText != null)
        {
            scoreText.text = "Score: " + score;
        }

        if (score < 0)
        {
            SceneManager.LoadScene("Lost");
        }
    }

    // Hàm tăng điểm
    public void AddScore(int value)
    {
        score += value;
        Debug.Log("Điểm tăng: " + value + ", Điểm hiện tại: " + score);
    }

    // Hàm trừ điểm
    public void SubtractScore(int value)
    {
        score -= value;
    }
}
