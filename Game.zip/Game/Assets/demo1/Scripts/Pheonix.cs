﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pheonix : MonoBehaviour {
	public int speed;
	public Fire x;
    void Start() { 
	
	}

	void Update() {
		if (Input.GetKey(KeyCode.W)) {
			transform.Translate(Vector3.up * speed * Time.deltaTime);
		}
		if (Input.GetKey(KeyCode.S)) {
			transform.Translate(Vector3.down * speed * Time.deltaTime);
		}
		if (Input.GetKey(KeyCode.A)) {
			transform.Translate(Vector3.left * speed * Time.deltaTime);
		}
		if (Input.GetKey(KeyCode.D)) {
			transform.Translate(Vector3.right * speed * Time.deltaTime);
		}
		if (Input.GetKeyDown(KeyCode.Space)) {
			Instantiate(x, transform.position, Quaternion.identity);
		}

    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("quaivat")) // Trúng Spear
        {
            GameManager.Instance.SubtractScore(10); // -10 điểm
        }
    }
}
