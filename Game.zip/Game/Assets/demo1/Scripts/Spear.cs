﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spear : MonoBehaviour {
	public float speed;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate(Vector3.up * speed * Time.deltaTime);
		if (transform.position.y > 6)
			//DestroyImmediate(this.gameObject);
			Destroy(gameObject);
	}

	void OnTriggerEnter2D(Collider2D obj) {
		if (obj.gameObject.tag == "phuonghoang") {
			//Destroy(this.gameObject);
            GameManager.Instance.SubtractScore(10); // -10 điểm
            Destroy(gameObject); // Xóa lao
        }
	}

}
