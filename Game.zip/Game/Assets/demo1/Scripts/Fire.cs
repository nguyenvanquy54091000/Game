﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fire : MonoBehaviour {
    public int speed;
	float line = 0;
    private static float lastFireTime = 0f; // Lần cuối cùng Fire được tạo
    private const float FIRE_COOLDOWN = 1f; // 1 giây cooldown

    void Start () {
		line = GameObject.Find("boss").transform.position.y;
        // Kiểm tra nếu đã đủ thời gian để tạo Fire mới
        if (Time.time - lastFireTime < FIRE_COOLDOWN)
        {
            Debug.LogWarning("Chưa đủ thời gian để tạo Fire mới!");
            Destroy(gameObject);
            return;
        }
        // Cập nhật thời gian tạo Fire
        lastFireTime = Time.time;
        /*if (currentFireCount >= MAX_FIRE_COUNT)
        {
            Destroy(gameObject);
            return;
        }
		currentFireCount++;
        */
        var boss = GameObject.Find("boss");
        if (boss != null)
            line = boss.transform.position.y;
    }
	
	// Update is called once per frame
	void Update () {
		transform.Translate(Vector3.down * speed * Time.deltaTime);
		if (transform.position.y < line)
			//Destroy(this.gameObject);
            Destroy(gameObject);
	}

	void OnTriggerEnter2D(Collider2D obj) {
        /*if (obj.CompareTag("quaivat")) // Tiêu diệt quái vật
        {
            Destroy(obj.gameObject); // Xóa quái vật
            Destroy(this.gameObject); // Xóa lửa
            GameManager.Instance.AddScore(3);
        }*/
        if (obj != null && obj.CompareTag("quaivat"))
        {
            Debug.Log("Đã tiêu diệt quái vật!");
            Destroy(obj.gameObject); // Xóa quái vật
            Destroy(this.gameObject); // Xóa lửa
            if (GameManager.Instance != null)
            {
                GameManager.Instance.AddScore(3);
                Debug.Log("Điểm hiện tại: " + GameManager.Instance.score); // +3 điểm
            }
            else
            {
                Debug.LogError("GameManager không được khởi tạo!");
            }
        }

    }
    private void DestroyFire()
    {
        Destroy(gameObject);
    }
}
